/**
 * GPII Process Reporter Tests
 *
 * Copyright 2015 Inclusive Design Research Centre, OCAD University
 *
 * Licensed under the New BSD license. You may not use this file except in
 * compliance with this License.
 *
 * You may obtain a copy of the License at
 * https://github.com/GPII/kettle/LICENSE.txt
 */

"use strict";

var fluid = require("infusion"),
    path = require("path"),
    jqUnit = fluid.require("node-jqunit"),
    configPath = path.resolve(__dirname, "./configs"),
    kettle = require("kettle"),
    gpii = fluid.registerNamespace("gpii");

require("universal");

kettle.loadTestingSupport();

fluid.registerNamespace("gpii.tests.processReporter");

fluid.defaults("gpii.tests.processReporter.platformReporterMock", {
    gradeNames: ["fluid.component"],
    invokers: {
        reportPlatform: {
            funcName: "fluid.identity",
            args: ["{processReporter}.platformReporter.options.platform"]
        }
    }
});

fluid.defaults("gpii.tests.processReporter", {
    gradeNames: ["gpii.processReporter.live"],
    components: {
        platformReporter: {
            type: "gpii.tests.processReporter.platformReporterMock",
            options: {
                platform: {
                    id: "SomeOS",
                    version: "6.6.6-666.fc66.x86-64"
                }
            }
        }
    },
    invokers: {
        testResponse: {
            funcName: "gpii.tests.processReporter.testRequestResponse",
            args: ["{arguments}.0", "{arguments}.1"]
        }
    },
    listeners: {
        onCreate: {
            funcName: "gpii.tests.processReporter.onCreate",
            args: ["{that}"]
        }
    }
});

gpii.tests.processReporter.testRequestResponse = function (data, expected) {
    jqUnit.assertDeepEq("ProcessReporter payload",
                        expected, JSON.parse(data));
};

gpii.tests.processReporter.onCreate = function (that) {
    debugger;
    var x = 5;
};

gpii.tests.processReporter.staticExpectedPayloadAll = {
    solutions: [
        {
            "id": "org.gnome.desktop.a11y.magnifier",
            "running": false
        },
        {
            "id": "org.gnome.desktop.a11y.keyboard",
            "running": true
        },
        {
            "id": "org.gnome.orca",
            "running": true
        }
    ],
    OS: {
        "id": "SomeOS",
        "version": "6.6.6-666.fc66.x86-64"
    }
};

gpii.tests.processReporter.staticExpectedPayloadSingle = {
    solutions:
    {
        "id": "org.gnome.desktop.a11y.keyboard",
        "running": true
    },
    OS: {
        "id": "SomeOS",
        "version": "6.6.6-666.fc66.x86-64"
    }
};

var testDefs = [
    {
        name: "Process Reporter tests -- all solutions",
        expect: 1,
        config: {
            configName: "gpii.processReporter.tests.live",
            configPath: configPath
        },
        expected: gpii.tests.processReporter.staticExpectedPayloadAll,
        components: {
            getRequest: {
                type: "kettle.test.request.http",
                options: {
                    path: "/processes",
                    method: "GET",
                    port: 8081
                }
            }
        },
        sequence: [{
            func: "{getRequest}.send"
        },
            {
                event: "{getRequest}.events.onComplete",
                listener: "gpii.tests.processReporter.testRequestResponse",
                args: ["{arguments}.0", "{that}.options.expected"]
            }
        ]
    },
    {
        name: "Process Reporter tests -- single solution",
        expect: 1,
        config: {
            configName: "gpii.processReporter.tests.live",
            configPath: configPath
        },
        expected: gpii.tests.processReporter.staticExpectedPayloadSingle,
        components: {
            getRequest: {
                type: "kettle.test.request.http",
                options: {
                    path: "/processes/org.gnome.desktop.a11y.keyboard",
                    method: "GET",
                    port: 8081
                }
            }
        },
        sequence: [{
            func: "{getRequest}.send"
        },
            {
                event: "{getRequest}.events.onComplete",
                listener: "gpii.tests.processReporter.testRequestResponse",
                args: ["{arguments}.0", "{that}.options.expected"]
            }]}
];

module.exports = kettle.test.bootstrapServer(testDefs);
